<template>
    <div id="app">
        <router-view/>
    </div>
</template>

<style>
html,
body,
#app {
    height: 100%;
    padding: 0;
    margin: 0;
    font-family: "Microsoft YaHei", Arial, Helvetica, sans-serif, "宋体";
    overflow: hidden;
}
</style>
